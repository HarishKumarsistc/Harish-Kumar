<?php
	session_start();

	session_unset();
?>